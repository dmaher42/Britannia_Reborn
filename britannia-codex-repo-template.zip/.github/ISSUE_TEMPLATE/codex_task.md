---
name: Codex Task
about: Ask Codex to work on the repo
title: "[codex] "
labels: ["codex"]
assignees: []
---

**High-level goal**
Describe the outcome you want.

**Details / constraints**
- Link to relevant files.
- Include acceptance criteria.

**Runbook for Codex**
- Read AGENTS.md
- Open a PR with code + short demo GIF
- Ensure tests pass (if present)

/cc @codex
